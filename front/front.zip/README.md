# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

license

Block Character by J-Toastie [CC-BY] via Poly Pizza

Volcano by Poly by Google [CC-BY] via Poly Pizza

<a href="https://www.flaticon.com/fr/icones-gratuites/couronne-de-laurier" title="couronne de laurier icônes">Couronne de laurier icônes créées par Freepik - Flaticon</a>

Volcano by Poly by Google [CC-BY] via Poly Pizza
