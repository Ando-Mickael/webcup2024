import React from "react";
import VeteranGallery from "../../components/VeteranGallery/VeteranGallery";

const VeteranGalleryPage = () => {
  return <VeteranGallery />;
};

export default VeteranGalleryPage;
