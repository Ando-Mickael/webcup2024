import React from "react";
import WebcupWorld from "../../components/WebcupWorld/WebcupWorld";

const WebcupWorldPage = () => {
  return <WebcupWorld />;
};

export default WebcupWorldPage;
